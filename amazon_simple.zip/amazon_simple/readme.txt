Enter links inside input.txt

enter terminal command: scrapy crawl amazon


