from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import AmazonItem

from time import sleep


class AmazonSpider(CrawlSpider):

    name = "amazon"

    super_link = "https://www.amazon.de/"

    counter = 0


    def __init__(self,*args, **kwargs):                    
        super(AmazonSpider, self).__init__(*args, **kwargs)   

        links = []

        file = open("input.txt","r")

        for link in file.readlines():
            links.append(link.replace("\n",""))

        self._url_list = links

        file.close()                                                              

    def start_requests(self):    

        for code in self._url_list: 

            yield Request(url = code,callback = self.product_page)

    def product_page(self, response):

        product = AmazonItem()

        product["title"] = response.css("#productTitle::text").extract_first().strip()
        
        product["Description"] = response.css("#feature-bullets .a-list-item::text").extract()

        if product["Description"]:
            product["Description"] = " ".join(product["Description"])
            product["Description"] = product["Description"].replace("\t","")
            product["Description"] = product["Description"].replace("\n","")
        
        product["Price"] = response.css("#priceblock_ourprice::text").extract_first()  

        if product["Price"]:
            product["Price"] = product["Price"].strip().replace("\xa0"," ")
        else:

            product["Price"] = response.css("#priceblock::text").extract_first()  

            if product["Price"]:
                product["Price"] = product["Price"].strip().replace("\xa0"," ")


        product["Image"] = response.css(".a-section.a-spacing-small span.a-list-item .a-button-text img::attr(src)").extract()


        yield product



